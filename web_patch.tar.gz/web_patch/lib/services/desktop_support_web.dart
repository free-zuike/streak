bool blockedByWindows(Object error) => false;

String? writeStartupLog(Object error, StackTrace stack) => null;
