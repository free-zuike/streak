
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform, kIsWeb;
import 'package:streak/core/utils/io_shim.dart';
import 'package:flutter/services.dart';

class DesktopWindow {
  const DesktopWindow._();

  static const _channel = MethodChannel('streak/window');

  static Future<void> setFullscreen(bool on) async {
    if (!(defaultTargetPlatform == TargetPlatform.windows) && !(defaultTargetPlatform == TargetPlatform.linux) && !(defaultTargetPlatform == TargetPlatform.macOS)) return;
    try {
      await _channel.invokeMethod<void>('fullscreen', on);
    } on PlatformException {
      return;
    } on MissingPluginException {
      return;
    }
  }
}
