import 'dart:io';

import 'package:streak/core/utils/app_dirs.dart';

bool blockedByWindows(Object error) =>
    Platform.isWindows &&
    error is FileSystemException &&
    error.osError?.errorCode == 5;

String? writeStartupLog(Object error, StackTrace stack) {
  if (isMobile) return null;
  try {
    final file = File('${Directory.systemTemp.path}/streak_startup_error.txt');
    file.writeAsStringSync('${DateTime.now()}
$error

$stack');
    return file.path;
  } catch (_) {
    return null;
  }
}
