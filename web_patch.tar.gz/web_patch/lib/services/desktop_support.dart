export 'desktop_support_web.dart' if (dart.library.io) 'desktop_support_io.dart';
