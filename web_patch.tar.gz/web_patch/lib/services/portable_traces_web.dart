/// Web 平台无 Windows 注册表可清理，no-op。
class PortableTraces {
  const PortableTraces._();

  static Future<void> clear(String appId) async {}
}
