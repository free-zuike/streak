
import 'package:flutter/foundation.dart' show defaultTargetPlatform, TargetPlatform, kIsWeb;
import 'package:streak/core/utils/io_shim.dart';
import 'package:flutter/material.dart';
import 'package:video_player_win/video_player_win.dart';

const focusVideoScenes = <String>[
  'cabin_rain',
  'fireplace_room',
  'girl_study',
  'cat_fireplace',
];

bool get hasVideoScenes => (defaultTargetPlatform == TargetPlatform.windows) || (defaultTargetPlatform == TargetPlatform.linux);

const focusVideoExtensions = ['mp4', 'mov', 'webm', 'mkv'];

bool isFocusVideo(String path) =>
    hasVideoScenes &&
    focusVideoExtensions.contains(path.split('.').last.toLowerCase());

String get _scenesDir =>
    '${shimFile(shimExePath()).parent.path}/data/scenes';

dynamic focusVideoFile(String name) => shimFile('$_scenesDir/$name.mp4');

dynamic focusVideoPoster(String name) => shimFile('$_scenesDir/$name.jpg');

class FocusVideoPoster extends StatelessWidget {
  const FocusVideoPoster({super.key, required this.name});

  final String name;

  @override
  Widget build(BuildContext context) {
    final poster = focusVideoPoster(name);
    if (!poster.existsSync()) {
      return const ColoredBox(color: Colors.black);
    }
    return Image.file(poster, fit: BoxFit.cover);
  }
}

class FocusVideoScene extends StatefulWidget {
  const FocusVideoScene({super.key, required this.file, required this.poster});

  final dynamic file;
  final Widget poster;

  @override
  State<FocusVideoScene> createState() => _FocusVideoSceneState();
}

class _FocusVideoSceneState extends State<FocusVideoScene> {
  WinVideoPlayerController? _controller;

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  void didUpdateWidget(FocusVideoScene oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.file.path == widget.file.path) return;
    _controller?.dispose();
    _controller = null;
    _load();
  }

  Future<void> _load() async {
    final file = widget.file;
    if (!file.existsSync()) return;
    final controller = WinVideoPlayerController.file(file);
    try {
      await controller.initialize();
      await controller.setLooping(true);
      await controller.setVolume(0);
      await controller.play();
    } catch (e) {
      debugPrint('Could not play the scene: $e');
      await controller.dispose();
      return;
    }
    if (!mounted) {
      await controller.dispose();
      return;
    }
    setState(() => _controller = controller);
  }

  @override
  void dispose() {
    _controller?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final controller = _controller;
    if (controller == null || !controller.value.isInitialized) {
      return widget.poster;
    }
    return FittedBox(
      fit: BoxFit.cover,
      clipBehavior: Clip.hardEdge,
      child: SizedBox(
        width: controller.value.size.width,
        height: controller.value.size.height,
        child: WinVideoPlayer(controller),
      ),
    );
  }
}
