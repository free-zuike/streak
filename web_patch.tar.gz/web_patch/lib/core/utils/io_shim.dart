export 'io_shim_web.dart' if (dart.library.io) 'io_shim_io.dart';
