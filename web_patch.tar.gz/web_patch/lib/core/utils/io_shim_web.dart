/// Web 平台：所有 dart:io 操作降级为链式 no-op mock。
class IoShim {
  const IoShim();
  dynamic noSuchMethod(Invocation invocation) => const IoShim();
}

class _ShimStat {
  int get size => 0;
  DateTime get modified => DateTime.fromMillisecondsSinceEpoch(0);
  dynamic noSuchMethod(Invocation invocation) => null;
}

class _ShimNode {
  final String path;
  const _ShimNode(this.path);
  bool existsSync() => false;
  bool exists() => false;
  dynamic statSync() => _ShimStat();
  Future<dynamic> readAsBytes() async => <int>[];
  Future<dynamic> readAsString() async => '';
  Future<dynamic> writeAsBytes(List<int> bytes, {dynamic mode, dynamic encoding}) async {}
  Future<dynamic> writeAsString(String content, {dynamic mode, dynamic encoding}) async {}
  dynamic copy(String target) => _ShimNode(target);
  dynamic rename(String target) => _ShimNode(target);
  dynamic createSync({bool recursive = false}) => this;
  dynamic create({bool recursive = false}) async => this;
  dynamic deleteSync({bool recursive = false}) => this;
  dynamic delete({bool recursive = false}) async => this;
  List<dynamic> listSync({bool recursive = false, bool followLinks = true}) => <dynamic>[];
  Stream<dynamic> list({bool recursive = false, bool followLinks = true}) => const Stream.empty();
  dynamic get uri => Uri.file(path);
  dynamic get absolute => this;
  dynamic noSuchMethod(Invocation invocation) => const IoShim();
}

dynamic shimFile(String path) => _ShimNode(path);
dynamic shimDir(String path) => _ShimNode(path);
dynamic shimSystemTemp() => const _ShimNode('/tmp');
Map<String, String> shimEnv() => const {};
String shimExePath() => 'streak.web';
String shimOS() => 'web';
Never shimExit(int code) => throw UnsupportedError('exit is not supported on web');
Future<dynamic> shimAppDir() async => const _ShimNode('/app-support');
