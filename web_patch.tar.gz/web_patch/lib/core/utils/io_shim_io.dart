import 'dart:io';

/// io 平台：真实 dart:io 透传。
File shimFile(String path) => File(path);
Directory shimDir(String path) => Directory(path);
Directory shimSystemTemp() => Directory.systemTemp;
Map<String, String> shimEnv() => Platform.environment;
String shimExePath() => Platform.resolvedExecutable;
String shimOS() => Platform.operatingSystem;
Never shimExit(int code) => exit(code);
Future<dynamic> shimAppDir() async => getTemporaryDirectory();
